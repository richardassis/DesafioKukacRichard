export default interface VehicleInterface{
    model: string;
    yearOfManofacture: string;
    readonly doorQuantitie: number;
    brand: string;
    text?: string | {};
}