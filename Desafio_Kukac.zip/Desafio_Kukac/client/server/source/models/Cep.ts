export default interface Cep {
    endereco: string
    bairro:string
    cidade: string
    estado:string
}