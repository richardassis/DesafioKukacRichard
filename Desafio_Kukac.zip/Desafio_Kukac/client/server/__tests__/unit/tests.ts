// import palindrome from '../../source/controllers/Palindrome.controller';

// test('expect to return an array that contains palindrome numbers', () => {
//     expect(palindrome.generatePalindromeNumbers(0, 100)).toBe(Array);
// })